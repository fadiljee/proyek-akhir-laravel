<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class UserModel extends Model
{
    //
    protected $table = 'data_user';
    protected $primaryKey = 'id';
}
